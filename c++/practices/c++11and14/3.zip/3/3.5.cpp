//
// 3.5.cpp
// c++1x tutorial
//
// created by changkun at shiyanlou.com
//
// 移动语义

#include <iostream> // std::cout
#include <utility>  // std::move
#include <vector>   // std::vector
#include <string>   // std::string

int main() {
    
    std::string str = "Hello world.";
    std::vector<std::string> v;
    
    // 使用 push_back(const T&), 即产生拷贝行为
    v.push_back(str);
    // 将输出 "str: Hello World."
    std::cout << "str: " << str << std::endl;
    
    // 将使用 push_back(const T&&), 没有拷贝行为
    // 而整个字符串会被移动到 vector 中，所以有时候会使用 std::move 
    // 来避免拷贝从而减少
    // 这布操作后，str中的指将会变为空
    v.push_back(std::move(str));
    // 将输出 "str: "
    std::cout << "str: " << str << std::endl;
    
    return 0;
}