// 3.1.cpp
// c++1x tutorial
//
// created by changkun at shiyanlou.com
//
// lambda experssion

#include <iostream>
#include <utility>
#include <memory>

void learn_lambda_func_1() {
	int value_1 = 1;
	auto copy_value_1 = [value_1] {
		return value_1;
	};
	value_1 = 100;
	auto stored_value_1 = copy_value_1();
	// 这时, stored_value_1 == 1, 而 value_1 == 100.
	// 因为 copy_value_1 在创建时就保存了一份 value_1 的拷贝
	std::cout << "value_1 = " << value_1 << std::endl;
	std::cout << "stored_value_1 = " << stored_value_1 << std::endl;
}

void learn_lambda_func_2() {
	int value_2 = 1;
	auto copy_value_2 = [&value_2] {
		return value_2;
	};
	value_2 = 100;
	auto stored_value_2 = copy_value_2();
	// 这时, stored_value_2 == 100, value_1 == 100.
	// 因为 copy_value_2 保存的是引用
	std::cout << "value_2 = " << value_2 << std::endl;
	std::cout << "stored_value_2 = " << stored_value_2 << std::endl;
}

void learn_lambda_func_3(){
    auto important = std::make_unique<int>(1);
    auto add = [v1 = 1, v2 = std::move(important)](int x, int y) -> int {
        return x+y+v1+(*v2);
    };
    std::cout << "add(3, 4) = " << add(3, 4) << std::endl;
}

void learn_lambda_func_4(){
    auto generic = [](auto x, auto y) {
        return x+y;
    };

    std::cout << "generic(1,2) = " << generic(1, 2) << std::endl;
    std::cout << "generic(1.1,2.2) = " << generic(1.1, 2.2) << std::endl;
}

int main() {
	//值捕获
	learn_lambda_func_1();
	//引用捕获
	learn_lambda_func_2();
	//表达式捕获
	learn_lambda_func_3();
	//泛型lambda
	learn_lambda_func_4();
	return 0;
}
